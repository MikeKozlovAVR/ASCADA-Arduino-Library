// Based on the work by DFRobot

#include "ASCADA.h"
#include "Arduino.h"

String rxBuffer;
String rxTagID;
String rxValue;

Tag_BOOL::Tag_BOOL(String tagID_){
	this->tagID = tagID_;
}
Tag_BOOL::Tag_BOOL(String tagID_, bool startValue){
	this->tagID = tagID_;
	this->value = startValue;
}
bool Tag_BOOL::setValue(bool value_){
	this->value = value_;
	return 1;
}
bool Tag_BOOL::getValue(){
	return this->value;
}
void Tag_BOOL::transmit(){
	String valueStr;
	if (this->value)
	{
		valueStr = "1";
	}
	else
	{
		valueStr = "0";
	}
	sendPack(this->tagID, valueStr);
}
bool Tag_BOOL::recieved(){
	if (rxTagID == this->tagID)
	{
		if (rxValue == "0")
		{
			this->value = false;
		}
		if (rxValue == "1")
		{
			this->value = true;
		}
		return 1;
	}
	else
	{
		return 0;
	}
}

Tag_INT::Tag_INT(String tagID_){
	this->tagID = tagID_;
}
Tag_INT::Tag_INT(String tagID_, int startValue){
	this->tagID = tagID_;
	this->value = startValue;
}
bool Tag_INT::setValue(int value_){
	this->value = value_;
	return 1;
}
int Tag_INT::getValue(){
	return this->value;
}
void Tag_INT::transmit(){
	sendPack(this->tagID, String(this->value));
}
bool Tag_INT::recieved(){
	if (rxTagID == this->tagID)
	{
		this->value = rxValue.toInt();
		return 1;
	}
	else
	{
		return 0;
	}
}

Tag_FLOAT::Tag_FLOAT(String tagID_){
	this->tagID = tagID_;
}
Tag_FLOAT::Tag_FLOAT(String tagID_, float startValue){
	this->tagID = tagID_;
	this->value = startValue;
}
bool Tag_FLOAT::setValue(float value_){
	this->value = value_;
	return 1;
}
float Tag_FLOAT::getValue(){
	return this->value;
}
void Tag_FLOAT::transmit(){
	String valueTMP = String(this->value);
    valueTMP.replace(".", ",");
	sendPack(this->tagID, valueTMP);
}
bool Tag_FLOAT::recieved(){
	if (rxTagID == this->tagID)
	{
		rxValue.replace(",", ".");
		char valchar[rxValue.length() + 1];
		rxValue.toCharArray(valchar, rxValue.length() + 1);    
		this->value = (float)atof(valchar);
		return 1;
	}
	else
	{
		return 0;
	}
}

Tag_DOUBLE::Tag_DOUBLE(String tagID_){
	this->tagID = tagID_;
}
Tag_DOUBLE::Tag_DOUBLE(String tagID_, double startValue){
	this->tagID = tagID_;
	this->value = startValue;
}
bool Tag_DOUBLE::setValue(double value_){
	this->value = value_;
	return 1;
}
double Tag_DOUBLE::getValue(){
	return this->value;
}
void Tag_DOUBLE::transmit(){
	String valueTMP = String(this->value);
    valueTMP.replace(".", ",");
	sendPack(this->tagID, valueTMP);
}
bool Tag_DOUBLE::recieved(){
	if (rxTagID == this->tagID)
	{
		rxValue.replace(",", ".");
		char valchar[rxValue.length() + 1];
		rxValue.toCharArray(valchar, rxValue.length() + 1);
		this->value = atof(valchar);
		return 1;
	}
	else
	{
		return 0;
	}
}

Tag_STRING::Tag_STRING(String tagID_){
	this->tagID = tagID_;
}
Tag_STRING::Tag_STRING(String tagID_, String startValue){
	this->tagID = tagID_;
	this->value = startValue;
}
bool Tag_STRING::setValue(String value_){
	this->value = value_;
	return 1;
}
String Tag_STRING::getValue(){
	return this->value;
}
void Tag_STRING::transmit(){
	sendPack(this->tagID, this->value);
}
bool Tag_STRING::recieved(){
	if (rxTagID == this->tagID)
	{
		this->value = rxValue;
		return 1;
	}
	else
	{
		return 0;
	}
}

bool recieveASCADA()
{
	if(PORT.available()>0)
		{
			char rxByte = PORT.read();
			rxBuffer = rxBuffer + rxByte;
			if (rxByte == STOPPER)
			{
				uint8_t Slicer = rxBuffer.indexOf(SEPARATOR);
				uint8_t Slicer_2 = rxBuffer.indexOf(STOPPER);
				rxTagID = rxBuffer.substring(0,Slicer);
				rxValue = rxBuffer.substring(Slicer+1, Slicer_2);
				rxBuffer = "";
				return true;
			}
			else
			{
				return false;
			}
		}
	else
	{
		return false;
	}
}

void clearBuffer()
{
	rxBuffer = "";
}

void sendPack(String tagID_, String valueStr_)
{
	PORT.print(tagID_ + SEPARATOR + valueStr_ + STOPPER);
}
	
