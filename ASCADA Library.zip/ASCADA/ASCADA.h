/*
  Copyright (c) 2022 ASCADA. All right reserved.
*/

#ifndef ASCADA_h
#define ASCADA_h
#include <Arduino.h>

#define PORT Serial
#define SEPARATOR '&'
#define STOPPER '*'

/*
enum TAGTYPE
{
  BOOL,
  INT,
  FLOAT,
  DOUBLE,
  STRING,
};
*/
bool recieveASCADA();
void clearBuffer();
void sendPack(String tagID_, String valueStr_);

class Tag_BOOL
{
  public:
	Tag_BOOL(String tagID_);
	Tag_BOOL(String tagID_, bool startValue);
	String tagID;
	bool value = false;
	//TAGTYPE tagType = BOOL;
	bool setValue(bool value_);
	bool getValue();
	void transmit();
	bool recieved();
};

class Tag_INT
{
  public:
	Tag_INT(String tagID_);
	Tag_INT(String tagID_, int startValue);
	String tagID;
	int value = 0;
	//TAGTYPE tagType = INT;
	bool setValue(int value_);
	int getValue();
	void transmit();
	bool recieved();
};

class Tag_FLOAT
{
  public:
	Tag_FLOAT(String tagID_);
	Tag_FLOAT(String tagID_, float startValue);
	String tagID;
	float value = 0;
	//TAGTYPE tagType = FLOAT;
	bool setValue(float value_);
	float getValue();
	void transmit();
	bool recieved();
};

class Tag_DOUBLE
{
  public:
	Tag_DOUBLE(String tagID_);
	Tag_DOUBLE(String tagID_, double startValue);
	String tagID;
	double value = 0;
	//TAGTYPE tagType = DOUBLE;
	bool setValue(double value_);
	double getValue();
	void transmit();
	bool recieved();
};

class Tag_STRING
{
  public:
	Tag_STRING(String tagID_);
	Tag_STRING(String tagID_, String startValue);
	String tagID;
	String value = "";
	//TAGTYPE tagType = STRING;
	bool setValue(String value_);
	String getValue();
	void transmit();
	bool recieved();
};

#endif